import { authHeader } from '../utils/auth'
const BASE = '/api/v1'

async function http(method, url, data, opts = {}){
  const headers = { 'Content-Type':'application/json', ...authHeader(), ...(opts.headers||{}) }
  const res = await fetch(url, { method, headers, body: data ? JSON.stringify(data) : undefined })
  if (!res.ok) {
    const text = await res.text().catch(()=> '')
    throw new Error(text || ('HTTP '+res.status))
  }
  if (opts.raw) return res
  const ct = res.headers.get('content-type') || ''
  return ct.includes('application/json') ? res.json() : res.blob()
}

export const AuthApi = {
  login: (username, password)   => http('POST', `${BASE}/auth/login`,    { username, password }),
  register: (username, password)=> http('POST', `${BASE}/auth/register`, { username, password })
}

export const RouteApi = {
  list:   (id)      => id ? http('GET', `${BASE}/routes?id=${id}`) : http('GET', `${BASE}/routes`),
  create: (payload) => http('POST', `${BASE}/routes`, payload),
  update: (id,p)    => http('PUT',  `${BASE}/routes/${id}`, p),
  remove: (id)      => http('DELETE', `${BASE}/routes/${id}`)
}

export const BusApi = {
  list:   ()        => http('GET', `${BASE}/buses`),
  get:    (id)      => http('GET', `${BASE}/buses/${id}`),
  create: (payload) => http('POST', `${BASE}/buses`, payload),
  update: (id,p)    => http('PUT',  `${BASE}/buses/${id}`, p),
  remove: (id)      => http('DELETE', `${BASE}/buses/${id}`)
}

export const TripApi = {
  list:   (id) => http('GET', `${BASE}/trips${id?`?id=${id}`:''}`),
  search: ({source, destination, date}) => {
    const qs = new URLSearchParams()
    if (source) qs.set('source', source)
    if (destination) qs.set('destination', destination)
    if (date && /^\d{4}-\d{2}-\d{2}$/.test(date)) qs.set('date', date)
    const q = qs.toString()
    return http('GET', `${BASE}/trips/search${q?`?${q}`:''}`)
  },
  create: (payload) => http('POST', `${BASE}/trips`, payload),
  update: (id,p)    => http('PUT',  `${BASE}/trips/${id}`, p),
  remove: (id)      => http('DELETE', `${BASE}/trips/${id}`)
}

export const BookingApi = {
  book:   (payload) => http('POST', `${BASE}/bookings/book`, payload),
  my:     ()        => http('GET',  `${BASE}/bookings/my`),
  get:    (id)      => http('GET',  `${BASE}/bookings/${id}`),
  cancel: (id)      => http('POST', `${BASE}/bookings/${id}/cancel`)
}

export const PaymentApi = {
  pay: (payload)   => http('POST', `${BASE}/payments/process`, payload),
  get: (paymentId) => http('GET',  `${BASE}/payments/process?paymentId=${paymentId}`)
}

export const TicketApi = {
  byPayment: (paymentId) => http('GET', `${BASE}/tickets/by-payment/${paymentId}`),
  get:       (id)        => http('GET', `${BASE}/tickets/${id}`),
  pdf:       async (id)  => http('GET', `${BASE}/tickets/${id}/pdf`, undefined, { raw:true })
                             .then(async res => new Blob([await res.arrayBuffer()], { type: 'application/pdf' }))
}

export const ReportApi = {
  payments:    () => http('GET', `${BASE}/reports/payments`),
  paymentsPdf: () => http('GET', `${BASE}/reports/payments/pdf`).then(b=>b),
  bookings:    () => http('GET', `${BASE}/reports/bookings`),
  bookingsPdf: () => http('GET', `${BASE}/reports/bookings/pdf`).then(b=>b),
}
