import { Routes, Route, Navigate } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Home from './pages/Home'
import Auth from './pages/Auth'
import SearchResults from './pages/SearchResults'
import SeatSelection from './pages/SeatSelection'
import Checkout from './pages/Checkout'
import Ticket from './pages/Ticket'
import MyBookings from './pages/MyBookings'

import ProtectedRoute from './components/ProtectedRoute'

// Admin pages
import AdminDashboard from './pages/admin/Dashboard'
import RoutesAdmin from './pages/admin/Routes'
import TripsAdmin from './pages/admin/Trips'
import BusesAdmin from './pages/admin/Buses'
import ReportsAdmin from './pages/admin/Reports'

export default function App(){
  return (
    <div>
      <Navbar/>
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/login" element={<Auth mode="login"/>} />
        <Route path="/register" element={<Auth mode="register"/>} />
        <Route path="/search" element={<SearchResults/>} />
        <Route path="/seats/:tripId" element={<SeatSelection/>} />
        <Route path="/checkout" element={<Checkout/>} />
        <Route path="/ticket/:id" element={<Ticket/>} />
        <Route path="/bookings" element={<ProtectedRoute><MyBookings/></ProtectedRoute>} />

        {/* Admin */}
        <Route path="/admin" element={<ProtectedRoute requireAdmin><AdminDashboard/></ProtectedRoute>} />
        <Route path="/admin/routes" element={<ProtectedRoute requireAdmin><RoutesAdmin/></ProtectedRoute>} />
        <Route path="/admin/trips" element={<ProtectedRoute requireAdmin><TripsAdmin/></ProtectedRoute>} />
        <Route path="/admin/buses" element={<ProtectedRoute requireAdmin><BusesAdmin/></ProtectedRoute>} />
        <Route path="/admin/reports" element={<ProtectedRoute requireAdmin><ReportsAdmin/></ProtectedRoute>} />

        <Route path="*" element={<Navigate to="/" replace/>} />
      </Routes>
      <Footer/>
    </div>
  )
}
