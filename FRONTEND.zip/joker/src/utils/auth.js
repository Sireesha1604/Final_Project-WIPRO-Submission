import jwt_decode from 'jwt-decode'

export function getToken(){
  return localStorage.getItem('token') || sessionStorage.getItem('token') || null
}
export function setToken(token, remember){
  if(remember) localStorage.setItem('token', token); else sessionStorage.setItem('token', token)
}
export function clearToken(){
  localStorage.removeItem('token'); sessionStorage.removeItem('token')
}
export function getRole(){
  const t = getToken(); if(!t) return null
  try{
    const decoded = jwt_decode(t)
    const r = decoded.role || decoded.roles || decoded.authorities || null
    if(!r) return null
    if(Array.isArray(r)) return r.find(x=>String(x).includes('ADMIN')) ? 'ADMIN' : 'USER'
    return String(r).includes('ADMIN') ? 'ADMIN' : 'USER'
  }catch{ return null }
}
export function isAdmin(){ return getRole() === 'ADMIN' }
export function getUsername(){
  const t = getToken(); if(!t) return null; try{ return jwt_decode(t)?.sub || null }catch{ return null }
}
export function authHeader(){ const t=getToken(); return t? { 'Authorization': 'Bearer ' + t } : {} }
