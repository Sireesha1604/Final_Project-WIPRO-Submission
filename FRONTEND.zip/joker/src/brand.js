export const BRAND_NAME = 'Siri Travels';
