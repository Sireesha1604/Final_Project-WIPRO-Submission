import { Link, NavLink, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { getUsername, isAdmin, clearToken } from '../utils/auth'

export default function Navbar() {
  const nav = useNavigate()
  const user = getUsername()
  const admin = isAdmin()
  const [open, setOpen] = useState(false)

  const logout = () => { clearToken(); nav('/login') }

  return (
    <div className="nav">
      <div className="nav-inner">
        <Link to="/" className="brand" style={{ fontSize: 22 }}>Siri Travels</Link>

        <NavLink to="/search" className="btn btn-ghost">Search</NavLink>
        {user && <NavLink to="/bookings" className="btn btn-ghost">My Bookings</NavLink>}

        {admin && (
          <div
            className="admin-block"
            onMouseEnter={() => setOpen(true)}
            onMouseLeave={() => setOpen(false)}
          >
            {/* Heading (not a button/pill) */}
            <span
              className="admin-heading"
              role="button"
              aria-haspopup="menu"
              aria-expanded={open}
              onClick={() => setOpen(o => !o)} // tap on mobile
            >
              Admin
              <svg className={`caret ${open ? 'rot' : ''}`} width="14" height="14" viewBox="0 0 24 24">
                <path fill="currentColor" d="M7 10l5 5 5-5z" />
              </svg>
            </span>

            <div className={`admin-menu ${open ? 'open' : ''}`} role="menu">
              <NavLink to="/admin"         className="menu-item" role="menuitem">Dashboard</NavLink>
              <NavLink to="/admin/routes"  className="menu-item" role="menuitem">Routes</NavLink>
              <NavLink to="/admin/buses"   className="menu-item" role="menuitem">Buses</NavLink>
              <NavLink to="/admin/trips"   className="menu-item" role="menuitem">Trips</NavLink>
              <NavLink to="/admin/reports" className="menu-item" role="menuitem">Reports</NavLink>
            </div>
          </div>
        )}

        <div className="spacer" />

        {!user ? (
          <div style={{ display: 'flex', gap: 8 }}>
            <NavLink to="/login" className="btn btn-primary">Login</NavLink>
            <NavLink to="/register" className="btn">Register</NavLink>
          </div>
        ) : (
          <button className="btn btn-danger" onClick={logout}>Logout</button>
        )}
      </div>
    </div>
  )
}
