export default function Footer(){
  return <div className="footer">© {new Date().getFullYear()} NeoBus · Krypton-dark UI</div>
}
