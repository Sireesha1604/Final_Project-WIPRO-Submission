import { useLocation, useNavigate } from 'react-router-dom';
import { PaymentApi } from '../services/api';
import { useEffect, useMemo, useState } from 'react';

export default function Checkout() {
  const { state } = useLocation();
  const nav = useNavigate();

  // initial state from router, with refresh fallback via localStorage
  const [booking, setBooking] = useState(() => state?.booking ?? null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');

  // normalize booking id (support id or bookingId)
  const bookingId = useMemo(() => {
    if (!booking) return null;
    return booking.id ?? booking.bookingId ?? null;
  }, [booking]);

  // refresh-safe booking cache
  useEffect(() => {
    if (!booking) {
      const saved = localStorage.getItem('neobus.lastBooking');
      if (saved) {
        try { setBooking(JSON.parse(saved)); } catch { /* ignore */ }
      }
    } else {
      localStorage.setItem('neobus.lastBooking', JSON.stringify(booking));
    }
  }, [booking]);

  if (!booking) {
    return (
      <div className="container">
        <div className="card">No booking found.</div>
      </div>
    );
  }

  const pay = async () => {
    if (!bookingId) {
      setErr('Missing booking id');
      return;
    }

    setErr('');
    setLoading(true);
    try {
      const res = await PaymentApi.pay({
        bookingId: Number(bookingId),
        amount: Number(booking.totalAmount ?? 0),
        paymentMethod: 'CARD'
      });
      // clear cached booking so we don't reuse it accidentally
      localStorage.removeItem('neobus.lastBooking');

      // backend returns { paymentId, ... }
      nav(`/ticket/${res.paymentId}`, { state: { payment: res, booking } });
    } catch (e) {
      // your http() throws a string (possibly JSON). Show a nice message.
      let msg = e?.message || 'Payment failed';
      try {
        const j = JSON.parse(msg);
        msg = j.message || j.error || msg;
      } catch { /* not JSON, keep raw */ }
      setErr(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h2 style={{ fontFamily: 'Montserrat', fontWeight: 800 }}>Checkout</h2>
      <div className="card">
        <div>
          Booking #{bookingId ?? '—'} — {booking.fromCity} → {booking.toCity}
        </div>
        <div>Seats: {booking.seats}</div>
        <div>Total: ₹{booking.totalAmount}</div>

        <button
          className="btn btn-primary"
          onClick={pay}
          disabled={loading || !bookingId}
          style={{ marginTop: 10 }}
          title={!bookingId ? 'Missing booking reference' : undefined}
        >
          {loading ? 'Processing…' : 'Pay now'}
        </button>

        {err && <div className="notice" style={{ marginTop: 10 }}>{err}</div>}
      </div>
    </div>
  );
}
