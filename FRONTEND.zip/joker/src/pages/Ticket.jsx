import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { TicketApi } from '../services/api'

export default function Ticket(){
  const { id } = useParams()
  const [ticket, setTicket] = useState(null)

  useEffect(()=>{ (async()=>{
    setTicket(await TicketApi.get(id))
  })() }, [id])

  const downloadPdf = async ()=>{
    const blob = await TicketApi.pdf(id)
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = `ticket-${id}.pdf`; a.click(); URL.revokeObjectURL(url)
  }

  return (
    <div className="container">
      <h2 style={{fontFamily:'Montserrat', fontWeight:800}}>E-Ticket</h2>
      {!ticket ? <div className="card">Loading…</div> : (
        <div className="card">
          <div className="badge">#{ticket.ticketNumber}</div>
          <h3 style={{margin:'8px 0'}}>{ticket.fromCity} → {ticket.toCity}</h3>
          <div>Seats: {ticket.seats}</div>
          <div>Amount: ₹{ticket.amount}</div>
          <div>Status: {ticket.status}</div>
          <button className="btn btn-primary" onClick={downloadPdf} style={{marginTop:10}}>Download PDF</button>
        </div>
      )}
    </div>
  )
}
