import { useEffect, useState } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { TripApi } from '../services/api'

export default function SearchResults(){
  const [params] = useSearchParams()
  const nav = useNavigate()
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)

  const source = params.get('source') || ''
  const destination = params.get('destination') || ''
  const date = params.get('date') || new Date().toISOString().slice(0,10)

  useEffect(()=>{ (async()=>{
    setLoading(true)
    try{
      const data = await TripApi.search({ source, destination, date })
      setRows(data || [])
    }finally{ setLoading(false) }
  })() }, [source, destination, date])

  return (
    <div className="container">
      <h2 style={{fontFamily:'Montserrat', fontWeight:800}}>Trips</h2>
      {loading ? <div className="card">Loading…</div> : (
        <div className="grid">
          {rows.map(r=>(
            <div className="card" key={r.id} style={{display:'grid', gridTemplateColumns:'1fr auto', gap:10}}>
              <div>
                <div className="badge">{r.route?.source} → {r.route?.destination}</div>
                <h3 style={{margin:'8px 0'}}>{r.bus?.busNumber} · {r.bus?.busType}</h3>
                <div>{new Date(r.tripDate).toLocaleDateString()}</div>
              </div>
              <div style={{display:'grid', alignContent:'center', justifyItems:'end', gap:8}}>
                <div style={{fontSize:22}}>₹{r.pricePerSeat}</div>
                <button className="btn btn-primary" onClick={()=>nav(`/seats/${r.id}`)}>Select Seats</button>
              </div>
            </div>
          ))}
          {!rows.length && <div className="card">No trips found for your search.</div>}
        </div>
      )}
    </div>
  )
}
