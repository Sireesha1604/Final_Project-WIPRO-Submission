import { useEffect, useState } from 'react'
import { BookingApi, BusApi } from '../services/api'

export default function MyBookings(){
  const [rows, setRows] = useState([])

  useEffect(()=>{ (async()=>{ setRows(await BookingApi.my()) })() }, [])

  const cancel = async (id)=>{
    if(!confirm('Cancel this booking?')) return
    await BookingApi.cancel(id)
    setRows(await BookingApi.my())
  }

  return (
    <div className="container">
      <h2 style={{fontFamily:'Montserrat', fontWeight:800}}>My Bookings</h2>
      <div className="grid">
        {rows.map(b=>(
          <div className="card" key={b.id} style={{display:'grid', gridTemplateColumns:'1fr auto', gap:10}}>
            <div>
              <div className="badge">#{b.ticketNumber}</div>
              <h3 style={{margin:'8px 0'}}>{b.fromCity} → {b.toCity}</h3>
              <div>Seats: {b.seats}</div>
              <div>Status: {b.status}</div>
            </div>
            <div style={{display:'grid', alignContent:'center', gap:8}}>
              <div>Total: ₹{b.totalAmount}</div>
              <button className="btn btn-danger" onClick={()=>cancel(b.id)}>Cancel</button>
            </div>
          </div>
        ))}
        {!rows.length && <div className="card">No bookings yet.</div>}
      </div>
    </div>
  )
}
