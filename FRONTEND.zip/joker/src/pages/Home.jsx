import { useNavigate } from 'react-router-dom'
import { useState } from 'react'

export default function Home(){
  const nav = useNavigate()
  const [form, setForm] = useState({ source:'Chennai', destination:'Bengaluru', date: new Date().toISOString().slice(0,10) })

  const submit = (e)=>{ e.preventDefault(); nav(`/search?source=${encodeURIComponent(form.source)}&destination=${encodeURIComponent(form.destination)}&date=${form.date}`) }

  return (
    <div className="container">
      <div className="hero">
        <h1>Fly by road.</h1>
      </div>

      <form onSubmit={submit} className="card" style={{marginTop:-40, display:'grid', gridTemplateColumns:'repeat(4,1fr) 140px', gap:10}}>
        <input className="input" placeholder="From" value={form.source} onChange={e=>setForm({...form, source:e.target.value})} />
        <input className="input" placeholder="To" value={form.destination} onChange={e=>setForm({...form, destination:e.target.value})} />
        <input className="input" type="date" value={form.date} onChange={e=>setForm({...form, date:e.target.value})} />
        <select className="input"><option>1 Traveller</option></select>
        <button className="btn btn-primary" type="submit">Search</button>
      </form>

      <div style={{marginTop:24}} className="grid grid-3">
        <div className="card"><div className="kpi"><strong>Live</strong> Seat availability</div></div>
        <div className="card"><div className="kpi"><strong>Secure</strong> Payments + e-Ticket</div></div>
        <div className="card"><div className="kpi"><strong>Fast</strong> Cancellations & refunds</div></div>
      </div>
    </div>
  )
}
