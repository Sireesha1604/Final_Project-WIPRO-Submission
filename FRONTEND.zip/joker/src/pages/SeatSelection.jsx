import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { TripApi, BusApi, BookingApi } from '../services/api'
import { getUsername } from '../utils/auth'

export default function SeatSelection(){
  const { tripId } = useParams()
  const nav = useNavigate()
  const [trip, setTrip] = useState(null)
  const [bus, setBus] = useState(null)
  const [selected, setSelected] = useState([])

  useEffect(()=>{ (async()=>{
    const t = await TripApi.list(tripId); setTrip(t)
    if(t?.bus?.id) setBus(await BusApi.get(t.bus.id))
  })() }, [tripId])

  const toggle = (i)=>{
    setSelected(prev => prev.includes(i) ? prev.filter(x=>x!==i) : [...prev, i])
  }

  const proceed = async ()=>{
    const user = getUsername()
    if(!user){ nav('/login'); return }
    // Simplified: userId is not known on frontend; backend can map username.
    const payload = {
      userId: 1,
      busId: trip.bus.id,
      fromCity: trip.route.source,
      toCity: trip.route.destination,
      seats: selected.length || 1
    }
    const res = await BookingApi.book(payload)
    nav('/checkout', { state:{ booking: res } })
  }

  const totalSeats = bus?.totalSeats || 40
  const grid = Array.from({length: totalSeats}, (_,i)=> i+1)

  return (
    <div className="container">
      <h2 style={{fontFamily:'Montserrat', fontWeight:800}}>Pick your seats</h2>
      {!trip ? <div className="card">Loading…</div> : (
        <div className="grid">
          <div className="card">
            <div className="badge">{trip.route?.source} → {trip.route?.destination}</div>
            <div style={{margin:'6px 0 12px'}}>Bus {trip.bus?.busNumber} · {trip.bus?.busType}</div>
            <div style={{display:'grid', gridTemplateColumns:'repeat(8,1fr)', gap:8}}>
              {grid.map(n => (
                <button key={n}
                  className={'btn '+(selected.includes(n) ? 'btn-primary' : 'btn-ghost')}
                  onClick={()=>toggle(n)}>{n}</button>
              ))}
            </div>
          </div>
          <div className="card">
            <div>Selected: {selected.join(', ') || 'None'}</div>
            <div>Fare: ₹{trip.pricePerSeat} × {selected.length || 1} = <b>₹{(trip.pricePerSeat||0) * (selected.length||1)}</b></div>
            <button className="btn btn-primary" onClick={proceed} style={{marginTop:10}}>Continue</button>
          </div>
        </div>
      )}
    </div>
  )
}
