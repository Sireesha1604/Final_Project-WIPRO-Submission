import { useEffect, useState } from 'react'
import { ReportApi } from '../../services/api'

export default function ReportsAdmin(){
  const [payments, setPayments] = useState([])
  const [bookings, setBookings] = useState([])
  const [loading, setLoading] = useState(true)

  const load = async () => {
    setLoading(true)
    try {
      const [p, b] = await Promise.all([ReportApi.payments().catch(()=>[]), ReportApi.bookings().catch(()=>[])])
      setPayments(p || []); setBookings(b || [])
    } finally { setLoading(false) }
  }

  useEffect(()=>{ load() }, [])

  const download = async (type) => {
    try {
      const blob = await (type === 'payments' ? ReportApi.paymentsPdf() : ReportApi.bookingsPdf())
      const url = URL.createObjectURL(blob); const a = document.createElement('a')
      a.href = url; a.download = type + '-report.pdf'; a.click(); URL.revokeObjectURL(url)
    } catch { alert('PDF not available') }
  }

  return (
    <div className="container">
      <h2 style={{fontFamily:'Montserrat', fontWeight:800}}>Reports</h2>
      <div style={{display:'flex', gap:10, marginBottom:12}}>
        <button className="btn btn-primary" onClick={()=>download('bookings')}>Download Bookings PDF</button>
        <button className="btn btn-primary" onClick={()=>download('payments')}>Download Payments PDF</button>
        <button className="btn btn-ghost" onClick={load}>Refresh</button>
      </div>

      {loading ? <div className="card">Loading…</div> : (
        <div className="grid">
          <div className="card">
            <h3>Payments</h3>
            <table className="table">
              <thead><tr><th>#</th><th>Amount</th><th>Status</th><th>Method</th><th>Date</th></tr></thead>
              <tbody>
                {payments.map((p,i)=>(
                  <tr key={i}>
                    <td>{p.id || p.paymentId || i+1}</td>
                    <td>₹{p.amount}</td>
                    <td>{p.status}</td>
                    <td>{p.paymentMethod || p.method}</td>
                    <td>{p.paymentDate ? new Date(p.paymentDate).toLocaleString() : '—'}</td>
                  </tr>
                ))}
                {!payments.length && <tr><td colSpan={5}><div className="notice">No payments.</div></td></tr>}
              </tbody>
            </table>
          </div>

          <div className="card">
            <h3>Bookings</h3>
            <table className="table">
              <thead><tr><th>#</th><th>User</th><th>From</th><th>To</th><th>Seats</th><th>Amount</th><th>Status</th></tr></thead>
              <tbody>
                {bookings.map((b,i)=>(
                  <tr key={i}>
                    <td>{b.id || b.bookingId || i+1}</td>
                    <td>{b.username || b.user?.username || '—'}</td>
                    <td>{b.fromCity}</td><td>{b.toCity}</td>
                    <td>{b.seats}</td><td>₹{b.totalAmount}</td><td>{b.status}</td>
                  </tr>
                ))}
                {!bookings.length && <tr><td colSpan={7}><div className="notice">No bookings.</div></td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
