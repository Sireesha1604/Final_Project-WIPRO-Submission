import { useEffect, useState } from 'react'
import { TripApi, RouteApi, BusApi, ReportApi } from '../../services/api'

export default function Dashboard(){
  const [counts, setCounts] = useState({ trips: 0, routes: 0, buses: 0, bookings: 0, payments: 0 })
  const [loading, setLoading] = useState(true)

  useEffect(()=>{ (async()=>{
    try {
      const [trips, routes, buses, bookings, payments] = await Promise.all([
        TripApi.list(), RouteApi.list(), BusApi.list(), ReportApi.bookings().catch(()=>[]), ReportApi.payments().catch(()=>[])
      ])
      setCounts({
        trips: Array.isArray(trips) ? trips.length : (trips ? 1 : 0),
        routes: routes.length || 0,
        buses: buses.length || 0,
        bookings: bookings.length || 0,
        payments: payments.length || 0
      })
    } finally { setLoading(false) }
  })() }, [])

  return (
    <div className="container">
      <h2 style={{fontFamily:'Montserrat', fontWeight:800}}>Admin Dashboard</h2>
      {loading ? <div className="card">Loading…</div> : (
        <div className="grid grid-3">
          <div className="card"><div className="kpi"><strong>{counts.routes}</strong> Routes</div></div>
          <div className="card"><div className="kpi"><strong>{counts.buses}</strong> Buses</div></div>
          <div className="card"><div className="kpi"><strong>{counts.trips}</strong> Trips</div></div>
          <div className="card"><div className="kpi"><strong>{counts.bookings}</strong> Bookings</div></div>
          <div className="card"><div className="kpi"><strong>{counts.payments}</strong> Payments</div></div>
        </div>
      )}
    </div>
  )
}
