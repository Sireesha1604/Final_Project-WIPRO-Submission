import { useEffect, useState } from 'react'
import { TripApi, RouteApi, BusApi } from '../../services/api'

export default function TripsAdmin(){
  const [rows, setRows] = useState([])
  const [routes, setRoutes] = useState([])
  const [buses, setBuses] = useState([])
  const [form, setForm] = useState({ routeId:'', busId:'', tripDate:'', pricePerSeat:0 })
  const [editing, setEditing] = useState(null)

  const load = async () => {
    const [trips, rs, bs] = await Promise.all([TripApi.list(), RouteApi.list(), BusApi.list()])
    setRows(Array.isArray(trips) ? trips : (trips ? [trips] : []))
    setRoutes(rs); setBuses(bs)
  }
  useEffect(()=>{ load() }, [])

  const submit = async (e) => {
    e.preventDefault()
    const payload = { routeId: Number(form.routeId), busId: Number(form.busId), tripDate: form.tripDate, pricePerSeat: Number(form.pricePerSeat) }
    if (editing) await TripApi.update(editing.id, payload)
    else await TripApi.create(payload)
    setForm({ routeId:'', busId:'', tripDate:'', pricePerSeat:0 }); setEditing(null); await load()
  }

  const editRow = (r) => {
    setEditing(r)
    setForm({
      routeId: r.route?.id || '',
      busId: r.bus?.id || '',
      tripDate: (r.tripDate || '').slice(0,10),
      pricePerSeat: r.pricePerSeat || 0
    })
  }
  const del = async (id) => { if (!confirm('Delete this trip?')) return; await TripApi.remove(id); await load() }

  return (
    <div className="container">
      <h2 style={{fontFamily:'Montserrat', fontWeight:800}}>Trips</h2>

      <form onSubmit={submit} className="card" style={{display:'grid', gridTemplateColumns:'repeat(4,1fr) 1fr', gap:10}}>
        <select className="input" value={form.routeId} onChange={e=>setForm({...form, routeId:e.target.value})}>
          <option value="">Select Route</option>
          {routes.map(r=>(<option key={r.id} value={r.id}>{r.source} → {r.destination}</option>))}
        </select>
        <select className="input" value={form.busId} onChange={e=>setForm({...form, busId:e.target.value})}>
          <option value="">Select Bus</option>
          {buses.map(b=>(<option key={b.id} value={b.id}>{b.busNumber} · {b.busType}</option>))}
        </select>
        <input className="input" type="date" value={form.tripDate} onChange={e=>setForm({...form, tripDate:e.target.value})} />
        <input className="input" type="number" placeholder="Price per seat" value={form.pricePerSeat} onChange={e=>setForm({...form, pricePerSeat:e.target.value})} />
        <button className="btn btn-primary" type="submit">{editing ? 'Update' : 'Create'}</button>
      </form>

      <div className="card" style={{marginTop:12}}>
        <table className="table">
          <thead><tr><th>#</th><th>Route</th><th>Date</th><th>Bus</th><th>Price</th><th></th></tr></thead>
          <tbody>
            {rows.map(r=>(
              <tr key={r.id}>
                <td>{r.id}</td>
                <td>{r.route?.source} → {r.route?.destination}</td>
                <td>{new Date(r.tripDate || Date.now()).toLocaleDateString()}</td>
                <td>{r.bus?.busNumber} · {r.bus?.busType}</td>
                <td>₹{r.pricePerSeat}</td>
                <td style={{display:'flex', gap:8}}>
                  <button className="btn btn-ghost" onClick={()=>editRow(r)}>Edit</button>
                  <button className="btn btn-danger" onClick={()=>del(r.id)}>Delete</button>
                </td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan={6}><div className="notice">No trips yet.</div></td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  )
}
