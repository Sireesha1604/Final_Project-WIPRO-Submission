import { useEffect, useState } from 'react'
import { BusApi, RouteApi } from '../../services/api'

export default function BusesAdmin(){
  const [rows, setRows] = useState([])
  const [routes, setRoutes] = useState([])
  const [form, setForm] = useState({ busNumber:'', busType:'AC', totalSeats:40, availableSeats:40, routeId:'' })
  const [editing, setEditing] = useState(null)

  const load = async () => { setRows(await BusApi.list()); setRoutes(await RouteApi.list()) }
  useEffect(()=>{ load() }, [])

  const submit = async (e) => {
    e.preventDefault()
    const payload = { busNumber: form.busNumber, busType: form.busType, totalSeats: Number(form.totalSeats), availableSeats: Number(form.availableSeats) }
    if (form.routeId) payload.routeId = Number(form.routeId)
    if (editing) await BusApi.update(editing.id, payload); else await BusApi.create(payload)
    setForm({ busNumber:'', busType:'AC', totalSeats:40, availableSeats:40, routeId:'' })
    setEditing(null)
    await load()
  }

  const editRow = (r) => {
    setEditing(r)
    setForm({ busNumber:r.busNumber || '', busType:r.busType || 'AC', totalSeats:r.totalSeats || 40, availableSeats:r.availableSeats || 40, routeId:'' })
  }
  const del = async (id) => { if (!confirm('Delete this bus?')) return; await BusApi.remove(id); await load() }

  return (
    <div className="container">
      <h2 style={{fontFamily:'Montserrat', fontWeight:800}}>Buses</h2>

      <form onSubmit={submit} className="card" style={{display:'grid', gridTemplateColumns:'repeat(5,1fr) 1fr', gap:10}}>
        <input className="input" placeholder="Bus number" value={form.busNumber} onChange={e=>setForm({...form, busNumber:e.target.value})} />
        <select className="input" value={form.busType} onChange={e=>setForm({...form, busType:e.target.value})}>
          <option>AC</option><option>Non-AC</option><option>Sleeper</option><option>Volvo</option>
        </select>
        <input className="input" type="number" placeholder="Total seats" value={form.totalSeats} onChange={e=>setForm({...form, totalSeats:e.target.value})} />
        <input className="input" type="number" placeholder="Available seats" value={form.availableSeats} onChange={e=>setForm({...form, availableSeats:e.target.value})} />
        <select className="input" value={form.routeId} onChange={e=>setForm({...form, routeId:e.target.value})}>
          <option value="">Route label (optional)</option>
          {routes.map(r=>(<option key={r.id} value={r.id}>{r.source} → {r.destination}</option>))}
        </select>
        <button className="btn btn-primary" type="submit">{editing ? 'Update' : 'Create'}</button>
      </form>

      <div className="card" style={{marginTop:12}}>
        <table className="table">
          <thead><tr><th>#</th><th>Bus #</th><th>Type</th><th>Total</th><th>Avail</th><th></th></tr></thead>
          <tbody>
            {rows.map(r=>(
              <tr key={r.id}>
                <td>{r.id}</td><td>{r.busNumber}</td><td>{r.busType}</td><td>{r.totalSeats}</td><td>{r.availableSeats}</td>
                <td style={{display:'flex', gap:8}}>
                  <button className="btn btn-ghost" onClick={()=>editRow(r)}>Edit</button>
                  <button className="btn btn-danger" onClick={()=>del(r.id)}>Delete</button>
                </td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan={6}><div className="notice">No buses yet.</div></td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  )
}
