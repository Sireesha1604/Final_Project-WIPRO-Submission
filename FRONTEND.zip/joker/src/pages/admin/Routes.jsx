import { useEffect, useState } from 'react'
import { RouteApi } from '../../services/api'

export default function RoutesAdmin(){
  const [rows, setRows] = useState([])
  const [form, setForm] = useState({ source:'', destination:'', distance:0, duration:'' })
  const [editing, setEditing] = useState(null)

  const load = async () => setRows(await RouteApi.list())

  useEffect(()=>{ load() }, [])

  const submit = async (e) => {
    e.preventDefault()
    if (editing) {
      await RouteApi.update(editing.id, form)
    } else {
      await RouteApi.create(form)
    }
    setForm({ source:'', destination:'', distance:0, duration:'' })
    setEditing(null)
    await load()
  }

  const editRow = (r) => { setEditing(r); setForm({ source:r.source, destination:r.destination, distance:r.distance, duration:r.duration }) }
  const del = async (id) => { if (!confirm('Delete this route?')) return; await RouteApi.remove(id); await load() }

  return (
    <div className="container">
      <h2 style={{fontFamily:'Montserrat', fontWeight:800}}>Routes</h2>

      <form onSubmit={submit} className="card" style={{display:'grid', gridTemplateColumns:'repeat(4,1fr) auto', gap:10}}>
        <input className="input" placeholder="Source" value={form.source} onChange={e=>setForm({...form, source:e.target.value})} />
        <input className="input" placeholder="Destination" value={form.destination} onChange={e=>setForm({...form, destination:e.target.value})} />
        <input className="input" type="number" placeholder="Distance" value={form.distance} onChange={e=>setForm({...form, distance:Number(e.target.value)})} />
        <input className="input" placeholder="Duration" value={form.duration} onChange={e=>setForm({...form, duration:e.target.value})} />
        <button className="btn btn-primary" type="submit">{editing ? 'Update' : 'Create'}</button>
      </form>

      <div className="card" style={{marginTop:12}}>
        <table className="table">
          <thead><tr><th>#</th><th>Source</th><th>Destination</th><th>Distance</th><th>Duration</th><th></th></tr></thead>
          <tbody>
            {rows.map(r=>(
              <tr key={r.id}>
                <td>{r.id}</td><td>{r.source}</td><td>{r.destination}</td><td>{r.distance}</td><td>{r.duration}</td>
                <td style={{display:'flex', gap:8}}>
                  <button className="btn btn-ghost" onClick={()=>editRow(r)}>Edit</button>
                  <button className="btn btn-danger" onClick={()=>del(r.id)}>Delete</button>
                </td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan={6}><div className="notice">No routes yet.</div></td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  )
}
