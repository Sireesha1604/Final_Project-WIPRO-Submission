import { useState } from 'react'
import { AuthApi } from '../services/api'
import { setToken } from '../utils/auth'
import { useNavigate } from 'react-router-dom'

export default function Auth({ mode='login' }){
  const [username, setUsername] = useState('user1@example.com')
  const [password, setPassword] = useState('pass123')
  const [remember, setRemember] = useState(true)
  const [msg, setMsg] = useState('')
  const nav = useNavigate()

  const submit = async (e)=>{
    e.preventDefault()
    try{
      const res = mode==='login'
        ? await AuthApi.login(username, password)
        : await AuthApi.register(username, password)
      if(res?.token){ setToken(res.token, remember); nav('/') } else setMsg(res?.message || 'OK')
    } catch(e){ setMsg(String(e.message||e)) }
  }

  return (
    <div className="container" style={{maxWidth:520}}>
      <h2 style={{fontFamily:'Montserrat', fontWeight:800}}>{mode==='login'?'Login':'Register'}</h2>
      <form onSubmit={submit} className="card" style={{display:'grid', gap:12}}>
        <input className="input" placeholder="Email" value={username} onChange={e=>setUsername(e.target.value)} />
        <input className="input" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
        <label style={{display:'flex', gap:8, alignItems:'center'}}>
          <input type="checkbox" checked={remember} onChange={e=>setRemember(e.target.checked)} />
          Keep me signed in
        </label>
        <button className="btn btn-primary" type="submit">{mode==='login'?'Login':'Create account'}</button>
        {msg && <div className="notice">{msg}</div>}
      </form>
    </div>
  )
}
