# THEME NOTES (Superman Dark)

- Bases: deep navy/charcoal
  - bg-0 #0B1220
  - bg-1 #0E1626
- Accents:
  - Electric blue #0AA1FF (primary)
  - Krypton red #D32F2F (danger)
- Surfaces: glassy with blur + soft glow
- Radii: 18px cards, 14px buttons
- Typography: Montserrat (headings), Inter (body)

Applied to:
- Navbar: blurred glass, borders, glow
- Buttons: primary blue, danger red, ghost subtle
- Cards: glass gradient, border, glow
- Inputs: clear contrast, focus ring in blue
- Hero: gradient + image overlay
